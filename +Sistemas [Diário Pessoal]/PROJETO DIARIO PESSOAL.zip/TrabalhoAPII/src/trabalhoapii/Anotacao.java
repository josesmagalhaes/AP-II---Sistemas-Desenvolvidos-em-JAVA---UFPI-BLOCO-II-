package trabalhoapii;

public class Anotacao {
    private String tipo;
    private String data;
    private String sentimento;

    public Anotacao(String tipo, String data, String sentimento) {
        this.tipo = tipo;
        this.data = data;
        this.sentimento = sentimento;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getSentimento() {
        return sentimento;
    }

    public void setSentimento(String sentimento) {
        this.sentimento = sentimento;
    }

    @Override
    public String toString() {
        return "\n" + "Tipo: " + tipo + "\nData: " + data + "\nMeu sentimento: " + sentimento + '\n';
    }
    
    
    
    
}

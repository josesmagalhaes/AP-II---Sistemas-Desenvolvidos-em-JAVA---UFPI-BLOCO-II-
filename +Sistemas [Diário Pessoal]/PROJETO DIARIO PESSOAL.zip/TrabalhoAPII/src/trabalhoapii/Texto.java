package trabalhoapii;

public class Texto {
    private String titulo;
    private Escritor autor;
    private Anotacao anotacao;

    public Texto(String titulo, Escritor autor, Anotacao anotacao) {
        this.titulo = titulo;
        this.autor = autor;
        this.anotacao = anotacao;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public Escritor getAutor() {
        return autor;
    }

    public void setAutor(Escritor autor) {
        this.autor = autor;
    }

    public Anotacao getAnotacao() {
        return anotacao;
    }

    public void setAnotacao(Anotacao anotacao) {
        this.anotacao = anotacao;
    }

    @Override
    public String toString() {
        return "MEU DIÁRIO PESSOAL\n" + "TITULO: " + titulo + "" + autor + "" + anotacao + '\n';
    }
    
    
    
}

package trabalhoapii;

public class Relato extends Anotacao{
    private String descricao;
    
    public Relato(String tipo, String data, String sentimento, String descricao) {
        super(tipo, data, sentimento);
        this.descricao = descricao;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    @Override
    public String toString() {
        return "Relato: \n" +super.toString()+ "" + descricao + '\n';
    }
    
}

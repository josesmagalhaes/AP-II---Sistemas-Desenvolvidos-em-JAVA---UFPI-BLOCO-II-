package trabalhoapii;

public interface Seguranca {
    String senha = "MINHA SENHA";
    
}

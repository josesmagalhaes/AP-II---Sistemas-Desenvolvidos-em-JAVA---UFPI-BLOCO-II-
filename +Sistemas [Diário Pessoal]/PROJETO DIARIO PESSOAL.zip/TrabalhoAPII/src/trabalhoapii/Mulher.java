package trabalhoapii;

public class Mulher extends Escritor{
    private String status;
    private String signo;
    
    public Mulher(String nome, int idade, String telefone, String status, String signo) {
        super(nome, idade, telefone);
        this.status = status;
        this.signo = signo;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSigno() {
        return signo;
    }

    public void setSigno(String signo) {
        this.signo = signo;
    }

    @Override
    public String toString() {
        return "" +super.toString()+ "\nStatus: " + status + "\nSigno" + signo + '\n';
    }
    
}

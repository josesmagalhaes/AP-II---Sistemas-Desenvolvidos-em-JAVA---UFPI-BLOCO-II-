package trabalhoapii;

public class Homem extends Escritor{
    private String status;
    private String time;
    
    public Homem(String nome, int idade, String telefone, String status, String time) {
        super(nome, idade, telefone);
        this.status = status;
        this.time = time;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    @Override
    public String toString() {
        return "" +super.toString()+ "\nStatus: " + status + "\nTime que torce: " + time + '\n';
    }
    
}

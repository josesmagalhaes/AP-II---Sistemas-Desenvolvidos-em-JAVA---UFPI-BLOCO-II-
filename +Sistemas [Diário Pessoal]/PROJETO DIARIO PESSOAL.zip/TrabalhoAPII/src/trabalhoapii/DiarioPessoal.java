package trabalhoapii;

public class DiarioPessoal {

    public static void main(String[] args) {
        
        Escritor joao = new Homem ("Joao Silva Cardoso",15,"(86) 99985 5512","A vida e bela como o vento!","Flamengo");
        Escritor carla = new Mulher ("Carla Samily Sousa",17,"(87) 98122 5478","As flores sao belas na primavera","Peixes");
        
        Anotacao segunda = new Relato ("Relato diário","22/11/2017","Felicidade","{Hoje tirei 10,0 em matematica!}");
        Anotacao segundaTarde = new Poema ("Meus poemas","22/11/2017","Apaixonada","{O amor e fogo que ardem e nao se ver...}");
        
        Texto paginaUM = new Texto ("Aconteceu no meu dia",joao,segunda);
        System.out.println(paginaUM.toString());
        Texto paginaDOIS = new Texto ("Poema para minha emocao",carla,segundaTarde);
        System.out.println("");
        System.out.println(paginaDOIS.toString());

    }
    
}

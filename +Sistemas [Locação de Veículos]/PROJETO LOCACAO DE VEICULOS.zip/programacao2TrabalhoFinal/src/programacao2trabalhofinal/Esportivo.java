package programacao2trabalhofinal;

public class Esportivo extends Veiculo{
    private double velocidadeMaxima;
    
    public Esportivo(String marca, String modelo, String placa, double velocidadeMaxima) {
        super(marca, modelo, placa);
        this.velocidadeMaxima = velocidadeMaxima;
    }

    public double getVelocidadeMaxima() {
        return velocidadeMaxima;
    }

    public void setVelocidadeMaxima(double velocidadeMaxima) {
        this.velocidadeMaxima = velocidadeMaxima;
    }

    @Override
    public String toString() {
        return "Veiculo Esportivo: " + super.toString()+"Velocidade Maxima: " + velocidadeMaxima + '\n';
    }
    
}

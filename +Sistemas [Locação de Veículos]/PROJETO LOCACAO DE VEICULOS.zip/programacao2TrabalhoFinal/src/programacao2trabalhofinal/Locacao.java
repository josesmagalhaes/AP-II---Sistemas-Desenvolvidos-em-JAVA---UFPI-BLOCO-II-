package programacao2trabalhofinal;

public class Locacao {
    private String dataLocacao;
    private String dataDevolucao;
    private Pessoa atendente;
    private Pessoa cliente;
    private Veiculo veiculo;

    public Locacao(String dataLocacao, String dataDevolucao, Pessoa atendente, Pessoa cliente, Veiculo veiculo) {
        this.dataLocacao = dataLocacao;
        this.dataDevolucao = dataDevolucao;
        this.atendente = atendente;
        this.cliente = cliente;
        this.veiculo = veiculo;
    }

    public String getDataLocacao() {
        return dataLocacao;
    }

    public void setDataLocacao(String dataLocacao) {
        this.dataLocacao = dataLocacao;
    }

    public String getDataDevolucao() {
        return dataDevolucao;
    }

    public void setDataDevolucao(String dataDevolucao) {
        this.dataDevolucao = dataDevolucao;
    }

    public Pessoa getAtendente() {
        return atendente;
    }

    public void setAtendente(Pessoa atendente) {
        this.atendente = atendente;
    }

    public Pessoa getCliente() {
        return cliente;
    }

    public void setCliente(Pessoa cliente) {
        this.cliente = cliente;
    }

    public Veiculo getVeiculo() {
        return veiculo;
    }

    public void setVeiculo(Veiculo veiculo) {
        this.veiculo = veiculo;
    }

    @Override
    public String toString() {
        return "Locacao: " + "\nData de Locacao: " + dataLocacao + "\nData de Devolucao: " + dataDevolucao + "\nAtendente:" + atendente + "\nCliente:\n" + cliente + "\n" + veiculo + '\n';
    }

    
    
    
}

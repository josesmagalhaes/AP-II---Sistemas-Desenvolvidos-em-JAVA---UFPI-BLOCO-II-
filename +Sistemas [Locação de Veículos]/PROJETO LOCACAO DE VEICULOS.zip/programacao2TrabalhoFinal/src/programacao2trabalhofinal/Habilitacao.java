package programacao2trabalhofinal;

public interface Habilitacao {
    String cnh = "32185496345-PI";
    
}

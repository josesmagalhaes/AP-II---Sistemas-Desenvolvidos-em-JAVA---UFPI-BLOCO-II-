package programacao2trabalhofinal;

public class LocacaoVeiculo {

    public static void main(String[] args) {
        
        Pessoa lucio = new Cliente ("Luio Azevedo Nunes",45,"3.541.289");
        Pessoa carol = new Cliente ("Carol Sndra Amaral",27,"1.254.452");
        Pessoa laura = new Atendente ("Laura Nunes Costa",22,"RH-7859322");
        
        Veiculo ferrari = new Esportivo ("Ferrari","GTS","LEX 4521",385.12);
        Veiculo ford = new Utilitario ("Ford","KA","LKV 8574",5);
        
        Locacao segunda = new Locacao ("12/08/2017","13/08/2017",laura,lucio,ferrari);
        System.out.println(segunda.toString());
        System.out.println("");
        Locacao terca = new Locacao ("13/08/2017","14/08/2017",laura,carol,ford);
        System.out.println(terca.toString());
    }
    
}

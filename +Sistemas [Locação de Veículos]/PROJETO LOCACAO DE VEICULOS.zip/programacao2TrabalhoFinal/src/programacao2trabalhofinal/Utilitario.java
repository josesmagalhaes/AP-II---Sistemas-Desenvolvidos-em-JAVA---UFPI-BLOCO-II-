package programacao2trabalhofinal;

public class Utilitario extends Veiculo{
    private int quantidadePassageiros;
    
    public Utilitario(String marca, String modelo, String placa, int quantidadePassageiros) {
        super(marca, modelo, placa);
        this.quantidadePassageiros = quantidadePassageiros;
    }

    public int getQuantidadePassageiros() {
        return quantidadePassageiros;
    }

    public void setQuantidadePassageiros(int quantidadePassageiros) {
        this.quantidadePassageiros = quantidadePassageiros;
    }

    @Override
    public String toString() {
        return "Veiculo Utilitario: " + "\nQuantidade de passageiros: " + quantidadePassageiros + '\n';
    }
    
}

package programacao2trabalhofinal;

public class Cliente extends Pessoa implements Habilitacao{
    private String rg;
    
    public Cliente(String nome, int idade, String rg) {
        super(nome, idade);
        this.rg = rg;
    }

    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    @Override
    public String toString() {
        return "" +super.toString()+ "RG: " + rg + "\nCNH: "+cnh+'\n';
    }
    
}

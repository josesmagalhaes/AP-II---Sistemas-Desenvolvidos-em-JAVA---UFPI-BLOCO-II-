package apiitrabalhofinal;

public interface Validade {
    String dataValidade = "15/11/2017";
    
}

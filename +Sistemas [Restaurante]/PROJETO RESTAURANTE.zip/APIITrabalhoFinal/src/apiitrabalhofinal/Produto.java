package apiitrabalhofinal;

public class Produto implements Validade{
    private String tipo;

    public Produto(String tipo) {
        this.tipo = tipo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "\n" + "Tipo: " + tipo + "\nData de validade: "+dataValidade+'\n';    }
    
    
    
}

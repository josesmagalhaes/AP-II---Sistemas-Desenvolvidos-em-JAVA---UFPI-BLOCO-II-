package apiitrabalhofinal;

public class Garcon extends Pessoa{
    private double salario;
    
    public Garcon(String nome, int idade, double salario) {
        super(nome, idade);
        this.salario = salario;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    @Override
    public String toString() {
        return "\nGarcon: " +super.toString()+ "Salario: " + salario + '\n';
    }
    
}

package apiitrabalhofinal;

public class Bebida extends Produto{
    private String nome;
    private double valor;
    
    public Bebida(String tipo, String nome, double valor) {
        super(tipo);
        this.nome = nome;
        this.valor = valor;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    @Override
    public String toString() {
        return "\nBebida: \n" + super.toString()+"Nome:  "+ nome + "\nValor: " + valor + '\n';
    }
    
}

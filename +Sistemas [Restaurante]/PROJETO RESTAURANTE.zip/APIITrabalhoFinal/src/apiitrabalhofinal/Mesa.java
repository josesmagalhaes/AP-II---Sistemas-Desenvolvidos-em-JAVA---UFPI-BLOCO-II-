package apiitrabalhofinal;

public class Mesa {
    private Pessoa cliente;
    private Pessoa garcon;
    private Pedido pedido;

    public Mesa(Pessoa cliente, Pessoa garcon, Pedido pedido) {
        this.cliente = cliente;
        this.garcon = garcon;
        this.pedido = pedido;
    }

    public Pessoa getCliente() {
        return cliente;
    }

    public void setCliente(Pessoa cliente) {
        this.cliente = cliente;
    }

    public Pessoa getGarcon() {
        return garcon;
    }

    public void setGarcon(Pessoa garcon) {
        this.garcon = garcon;
    }

    public Pedido getPedido() {
        return pedido;
    }

    public void setPedido(Pedido pedido) {
        this.pedido = pedido;
    }

    @Override
    public String toString() {
        return "Mesa: \n" + "" + cliente + "" + garcon + "" + pedido + '\n';
    }
    
    
    
}

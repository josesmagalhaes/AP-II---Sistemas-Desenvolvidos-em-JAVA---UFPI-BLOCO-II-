package apiitrabalhofinal;

public class Pedido {
    private int numero;
    private Produto pratoPrincipal;
    private Produto bebida;
    private Produto sobremesa;

    public Pedido(int numero, Produto pratoPrincipal, Produto bebida, Produto sobremesa) {
        this.numero = numero;
        this.pratoPrincipal = pratoPrincipal;
        this.bebida = bebida;
        this.sobremesa = sobremesa;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public Produto getPratoPrincipal() {
        return pratoPrincipal;
    }

    public void setPratoPrincipal(Produto pratoPrincipal) {
        this.pratoPrincipal = pratoPrincipal;
    }

    public Produto getBebida() {
        return bebida;
    }

    public void setBebida(Produto bebida) {
        this.bebida = bebida;
    }

    public Produto getSobremesa() {
        return sobremesa;
    }

    public void setSobremesa(Produto sobremesa) {
        this.sobremesa = sobremesa;
    }

    @Override
    public String toString() {
        return "\nPedido: \n" + "Numero do pedido: " + numero + "\n" +"\n"+ pratoPrincipal + "" + bebida + "" + sobremesa + '\n';
    }
    
    
    
}

package apiitrabalhofinal;

public class Restaurante {
  
    public static void main(String[] args) {
        
        Pessoa paulo = new Cliente ("Paulo Silva Pereira",27,"(86) 99541 8745");
        Pessoa pedro = new Garcon ("Pedro Soarez Cardoso",35,1200.05);
        
        Produto prato = new pratoPrincipal ("Prato Caseiro","Maria Isabel",32.85);
        Produto bebida = new Bebida ("Bebidas Frias","Coca Cola 2L",5.55);
        Produto sobremesa = new Sobremesa ("Sobremesa Gelada","Açaí com leite",12.25);
        
        Pedido numeroUM = new Pedido (1,prato,bebida,sobremesa);
        
        Mesa um = new Mesa (paulo,pedro,numeroUM);
        
        System.out.println(um.toString());
   
    }
    
}

package trabalhofinalalgoritmos;

public interface Entrada {
    String codigo = "ENTRADA AUTORIZADA";
    
}

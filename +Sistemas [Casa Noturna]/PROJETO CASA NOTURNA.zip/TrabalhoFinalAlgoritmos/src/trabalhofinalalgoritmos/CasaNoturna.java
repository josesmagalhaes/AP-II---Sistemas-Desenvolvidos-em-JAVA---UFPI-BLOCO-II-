
package trabalhofinalalgoritmos;


public class CasaNoturna {


    public static void main(String[] args) {
        
        Produto bebida = new Produto ("Cerveja",2.85);
        Produto bebidaQuente = new Produto ("Whisky",64.86);
        Produto bebidaSemalcool = new Produto ("Coquetel de Limão",12.55);
        Produto vitamina = new Produto ("Vitamina de Abacate",2.85);
        
        Funcionario pedro = new Seguranca ("Pedro Slaes Soarez",35,"2.547.896",1800.02);
        Funcionario carlos = new Barman ("Carlos Algusto Oliveira",27,"8.874.512",1500.02);
        
        Pessoa paula = new Cliente ("Paula Cardoso Costa",27,"3.254.888",bebida);
        Pessoa jessica = new Cliente ("Jessica Algusta Alves",32,"1.256.987",bebidaQuente);
        Pessoa josue = new Cliente ("Josue Almeida Fortes",25,"3.659.874",bebidaSemalcool);
        Pessoa ricardo = new Cliente ("Ricardo Pereira Silva",19,"4.253.652",vitamina);
        
        
        SessaoNoturna sabado = new SessaoNoturna(pedro,carlos,paula,jessica,josue,ricardo);
        System.out.println(sabado.toString());
    }
    
    
}

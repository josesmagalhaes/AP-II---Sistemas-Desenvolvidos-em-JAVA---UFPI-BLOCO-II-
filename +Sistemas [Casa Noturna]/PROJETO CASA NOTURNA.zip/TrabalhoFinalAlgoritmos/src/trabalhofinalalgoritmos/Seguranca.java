package trabalhofinalalgoritmos;

public class Seguranca extends Funcionario{
    
    public Seguranca(String nome, int idade, String rg, double salario) {
        super(nome, idade, rg, salario);
    }
    
}

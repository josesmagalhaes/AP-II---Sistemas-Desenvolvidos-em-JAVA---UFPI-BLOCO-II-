package trabalhofinalalgoritmos;

public class SessaoNoturna {
    private Funcionario seguranca;
    private Funcionario barman;
    private Pessoa cliente1;
    private Pessoa cliente2;
    private Pessoa cliente3;
    private Pessoa cliente4; 

    public SessaoNoturna(Funcionario seguranca, Funcionario barman, Pessoa cliente1, Pessoa cliente2, Pessoa cliente3, Pessoa cliente4) {
        this.seguranca = seguranca;
        this.barman = barman;
        this.cliente1 = cliente1;
        this.cliente2 = cliente2;
        this.cliente3 = cliente3;
        this.cliente4 = cliente4;
    }

    public Funcionario getSeguranca() {
        return seguranca;
    }

    public void setSeguranca(Funcionario seguranca) {
        this.seguranca = seguranca;
    }

    public Funcionario getBarman() {
        return barman;
    }

    public void setBarman(Funcionario barman) {
        this.barman = barman;
    }

    public Pessoa getCliente1() {
        return cliente1;
    }

    public void setCliente1(Pessoa cliente1) {
        this.cliente1 = cliente1;
    }

    public Pessoa getCliente2() {
        return cliente2;
    }

    public void setCliente2(Pessoa cliente2) {
        this.cliente2 = cliente2;
    }

    public Pessoa getCliente3() {
        return cliente3;
    }

    public void setCliente3(Pessoa cliente3) {
        this.cliente3 = cliente3;
    }

    public Pessoa getCliente4() {
        return cliente4;
    }

    public void setCliente4(Pessoa cliente4) {
        this.cliente4 = cliente4;
    }

    @Override
    public String toString() {
        return "SessaoNoturna:\n" + "\nSeguranca da noite: \n" + seguranca + "Barman da noite: \n" + barman + "Clientes da noite: \n" + cliente1 + "" + cliente2 + "" + cliente3 + "" + cliente4 + '\n';
    }
    
    
}

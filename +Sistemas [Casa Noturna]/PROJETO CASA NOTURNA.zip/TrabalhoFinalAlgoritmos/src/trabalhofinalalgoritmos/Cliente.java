
package trabalhofinalalgoritmos;

public class Cliente extends Pessoa implements Entrada{
    private Entrada entrada;
    private Produto produto;
    
    public Cliente(String nome, int idade, String rg, Produto produto) {
        super(nome, idade, rg);
        this.rg = rg;
        this.entrada = entrada;
        this.produto = produto;
    }

    public Entrada getEntrada() {
        return entrada;
    }

    public void setEntrada(Entrada entrada) {
        this.entrada = entrada;
    }

    public Produto getProduto() {
        return produto;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
    }

    @Override
    public String toString() {
        return "" + super.toString()+"Entrada: " + codigo + "\nProduto consumido\n" + produto + '\n';
    }
    
    
}

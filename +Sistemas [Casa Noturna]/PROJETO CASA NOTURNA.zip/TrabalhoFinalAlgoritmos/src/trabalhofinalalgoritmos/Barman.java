package trabalhofinalalgoritmos;

public class Barman extends Funcionario{
    
    public Barman(String nome, int idade, String rg, double salario) {
        super(nome, idade, rg, salario);
    }
    
    
}

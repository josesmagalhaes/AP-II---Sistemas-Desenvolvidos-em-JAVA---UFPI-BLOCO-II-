package trabalhofinalap2;


public class Bibliotecario extends Pessoa{
    private String turno;
    
    public Bibliotecario(String nome, int idade, String turno) {
        super(nome, idade);
        this.turno = turno;
    }

    public String getTurno() {
        return turno;
    }

    public void setTurno(String turno) {
        this.turno = turno;
    }

    @Override
    public String toString() {
        return ""+super.toString() + "Turno de trabalho: " + turno + '\n';
    }
    
}

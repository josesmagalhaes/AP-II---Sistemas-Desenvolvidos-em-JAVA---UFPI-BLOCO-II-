package trabalhofinalap2;

public class Monografia extends Exemplar{
    private String autor;
    private String titulo;
    private String curso;
    
    public Monografia(String codigo, String tipo, String autor, String titulo, String curso) {
        super(codigo, tipo);
        this.autor = autor;
        this.titulo = titulo;
        this.curso = curso;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    @Override
    public String toString() {
        return "\n" + super.toString()+"Autor: " + autor + "\nTitulo: " + titulo + "\nCurso: " + curso + '\n';
    }
    
    
}

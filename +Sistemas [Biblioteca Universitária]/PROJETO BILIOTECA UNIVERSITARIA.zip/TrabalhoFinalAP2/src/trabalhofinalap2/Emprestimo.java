package trabalhofinalap2;

public class Emprestimo {
    private Pessoa cliente;
    private Pessoa funcionario;
    private Exemplar exemplar;
    private String dataEmprestimo;
    private String dataDevolucao;

    public Emprestimo(Pessoa cliente, Pessoa funcionario, Exemplar exemplar, String dataEmprestimo, String dataDevolucao) {
        this.cliente = cliente;
        this.funcionario = funcionario;
        this.exemplar = exemplar;
        this.dataEmprestimo = dataEmprestimo;
        this.dataDevolucao = dataDevolucao;
    }

    public Pessoa getCliente() {
        return cliente;
    }

    public void setCliente(Pessoa cliente) {
        this.cliente = cliente;
    }

    public Pessoa getFuncionario() {
        return funcionario;
    }

    public void setFuncionario(Pessoa funcionario) {
        this.funcionario = funcionario;
    }

    public Exemplar getExemplar() {
        return exemplar;
    }

    public void setExemplar(Exemplar exemplar) {
        this.exemplar = exemplar;
    }

    public String getDataEmprestimo() {
        return dataEmprestimo;
    }

    public void setDataEmprestimo(String dataEmprestimo) {
        this.dataEmprestimo = dataEmprestimo;
    }

    public String getDataDevolucao() {
        return dataDevolucao;
    }

    public void setDataDevolucao(String dataDevolucao) {
        this.dataDevolucao = dataDevolucao;
    }

    @Override
    public String toString() {
        return "Emprestimo: \n" + "Nome do cliente: " + cliente + "\nNome do atendente: " + funcionario + "\nExemplar emprestado:" + exemplar + "\nData de emprestimo: " + dataEmprestimo + "\nData de devolucao: " + dataDevolucao + '\n';
    }
    
    
    
}

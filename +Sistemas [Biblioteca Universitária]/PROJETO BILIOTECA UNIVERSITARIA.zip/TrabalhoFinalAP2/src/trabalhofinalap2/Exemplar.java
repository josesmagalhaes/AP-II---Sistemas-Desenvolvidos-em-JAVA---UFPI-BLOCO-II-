
package trabalhofinalap2;

public class Exemplar {
    private String codigo;
    private String tipo;

    public Exemplar(String codigo, String tipo) {
        this.codigo = codigo;
        this.tipo = tipo;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "\n" + "Codigo: " + codigo + "\nTipo: " + tipo + '\n';
    }
    
    
    
}

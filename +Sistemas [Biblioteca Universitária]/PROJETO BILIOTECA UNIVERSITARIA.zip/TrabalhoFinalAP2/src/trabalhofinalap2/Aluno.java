
package trabalhofinalap2;

public class Aluno extends Cliente implements Registro{

    
    public Aluno(String nome, int idade, int telefone) {
        super(nome, idade, telefone);
    }

    @Override
    public String toString() {
        return "" +super.toString()+ "Matricula: " + matriculaa + '\n';
    }
    
}

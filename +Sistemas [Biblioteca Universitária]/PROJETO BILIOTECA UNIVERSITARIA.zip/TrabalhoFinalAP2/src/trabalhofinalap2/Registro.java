
package trabalhofinalap2;

public interface Registro {
    String matriculaa = "2017-052-2014RH";
    
}

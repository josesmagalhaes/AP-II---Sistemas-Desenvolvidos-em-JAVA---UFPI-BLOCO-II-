package trabalhofinalap2;

public class Periodico extends Exemplar{
    private String editora;
    
    public Periodico(String codigo, String tipo, String editora) {
        super(codigo, tipo);
        this.editora = editora;
    }

    public String getEditora() {
        return editora;
    }

    public void setEditora(String editora) {
        this.editora = editora;
    }

    @Override
    public String toString() {
        return "\n" + super.toString()+"Editora: " + editora + '\n';
    }
    
}

package trabalhofinalap2;

public class Cliente extends Pessoa{
    private int telefone;

    public Cliente(String nome, int idade, int telefone) {
        super(nome, idade);
        this.telefone = telefone;
    }

    public int getTelefone() {
        return telefone;
    }

    public void setTelefone(int telefone) {
        this.telefone = telefone;
    }
    
    
}

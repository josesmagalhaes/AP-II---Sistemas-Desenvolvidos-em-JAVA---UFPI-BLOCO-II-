package trabalhofinalap2;

public class BibliotecaUniversitaria {
    
    public static void main (String[] args){
        Pessoa pedro = new Aluno ("Pedro Sousa Sales",24,33422546);
        Pessoa isadora = new ComunidadeExterna ("Isadora Melissa Alves",35,32222121);
        Pessoa silvane = new ComunidadeExterna ("Silvane Sousa Pinho",25,33432154);        
        Pessoa isaac = new Bibliotecario ("Isaac Pereira Silva",28,"Manhã");
        Pessoa carla = new Bibliotecario ("Carla Sousa Abreu",27,"Tarde");
        
        Exemplar bolean = new Livro ("2005/12","Livros","Jacob Daghlian","ATLAS",12);
        Exemplar monografia = new Monografia ("2012/05","Documentos Academicos","Samara Almeida Campos","Comom aplicar a algebra de Boole em Laboratorios de Informatica","Sistemas de Informacao");
        Exemplar periodico = new Periodico ("2014/07","Periodicos","EDUFPA");
        
        Emprestimo segundaManha = new Emprestimo (pedro,isaac,bolean,"12/11/2017","13/11/2017");
        Emprestimo segundaTarde = new Emprestimo (isadora,carla,monografia,"12/11/2017","13/11/2017");
        Emprestimo tercaTarde = new Emprestimo (silvane,carla,periodico,"13/11/2017","15/11/2017");
        
        System.out.println(segundaManha.toString());
        System.out.println("");
        System.out.println(segundaTarde.toString());
        System.out.println("");
        System.out.println(tercaTarde.toString());
    }
    
}

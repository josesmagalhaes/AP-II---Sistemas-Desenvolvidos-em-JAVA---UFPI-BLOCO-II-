package trabalhofinalap2;

public class ComunidadeExterna extends Cliente{
    
    public ComunidadeExterna(String nome, int idade, int telefone) {
        super(nome, idade, telefone);
    }
    
}
